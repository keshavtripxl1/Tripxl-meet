// components/video-call/video-call.component.ts
import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../../services/auth.service';
import { VideoCallService } from '../../services/video-call.service';
import { ChatService, ChatMessage } from '../../services/chat.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-video-call',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './video-call.component.html',
  styleUrls: ['./video-call.component.css'],
})
export class VideoCallComponent implements OnInit, OnDestroy {
  @ViewChild('localVideo') localVideo!: ElementRef<HTMLVideoElement>;
  @ViewChild('remoteVideo') remoteVideo!: ElementRef<HTMLVideoElement>;
  @ViewChild('chatMessages') chatMessages!: ElementRef<HTMLDivElement>;

  @Input() roomId!: string;
  @Input() currentUser!: User;
  @Output() leaveRoom = new EventEmitter<void>();

  // Video call state
  connectionStatus = 'Connecting...';
  hasRemoteVideo = false;
  remoteUserName = '';
  isVideoOn = true;
  isAudioOn = true;
  isScreenSharing = false;

  // UI state
  showChat = false;
  localVideoPosition = { x: 20, y: 20 };
  isDragging = false;
  dragOffset = { x: 0, y: 0 };

  // Chat state
  messages: ChatMessage[] = [];
  newMessage = '';
  unreadMessages = 0;

  // Error handling
  errorMessage = '';
  successMessage = '';

  private subscriptions: Subscription[] = [];

  constructor(
    private videoCallService: VideoCallService,
    private chatService: ChatService
  ) {}

  async ngOnInit() {
    if (!this.currentUser) {
      console.error('❌ VideoCallComponent: currentUser is required but not provided');
      this.setError('User authentication required');
      return;
    }

    if (!this.roomId) {
      console.error('❌ VideoCallComponent: roomId is required but not provided');
      this.setError('Room ID is required');
      return;
    }

    console.log('🎥 VideoCallComponent initializing...', { 
      roomId: this.roomId, 
      user: this.currentUser.displayName || this.currentUser.phoneNumber 
    });

    try {
      await this.initializeVideoCall();
      this.initializeChat();
      this.setupEventListeners();
      
      console.log('✅ VideoCallComponent initialized successfully');
      
    } catch (error) {
      console.error('❌ Error initializing video call:', error);
      this.setError('Failed to initialize video call: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
  }


  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
    this.videoCallService.endCall();
    this.chatService.leaveRoom(this.roomId);
  }

  private async initializeVideoCall() {
    // Initialize WebRTC service
    await this.videoCallService.initializeCall(this.roomId, this.currentUser);
    
    // Set up video elements
    this.localVideo.nativeElement.srcObject = this.videoCallService.getLocalStream();
    
    // Listen for remote stream
    this.videoCallService.remoteStream$.subscribe(stream => {
      if (stream && stream.getTracks().length > 0) {
        this.remoteVideo.nativeElement.srcObject = stream;
        this.hasRemoteVideo = true;
      }
    });

    // Listen for connection status
    this.videoCallService.connectionStatus$.subscribe(status => {
      this.connectionStatus = status;
    });

    // Listen for remote user info
    this.videoCallService.remoteUser$.subscribe(user => {
      if (user) {
        this.remoteUserName = user.displayName || 'Remote User';
      }
    });
  }

  private initializeChat() {
    // Join chat room
    this.chatService.joinRoom(this.roomId, this.currentUser);
    
    // Listen for messages
    const messagesSub = this.chatService.getMessages(this.roomId).subscribe(messages => {
      const previousCount = this.messages.length;
      this.messages = messages;
      
      // Count unread messages if chat is closed
      if (!this.showChat && messages.length > previousCount) {
        this.unreadMessages += messages.length - previousCount;
      }
      
      // Auto-scroll to bottom
      setTimeout(() => this.scrollToBottom(), 100);
    });
    
    this.subscriptions.push(messagesSub);
  }

  private setupEventListeners() {
    // Handle browser close/refresh
    window.addEventListener('beforeunload', () => {
      this.videoCallService.endCall();
      this.chatService.leaveRoom(this.roomId);
    });
  }

  // Video controls
  toggleVideo() {
    this.isVideoOn = this.videoCallService.toggleVideo();
  }

  toggleAudio() {
    this.isAudioOn = this.videoCallService.toggleAudio();
  }

  async switchCamera() {
    try {
      await this.videoCallService.switchCamera();
      this.setSuccess('Camera switched');
    } catch (error) {
      this.setError('Failed to switch camera');
    }
  }

  async toggleScreenShare() {
    try {
      if (this.isScreenSharing) {
        await this.videoCallService.stopScreenShare();
        this.isScreenSharing = false;
        this.setSuccess('Screen sharing stopped');
      } else {
        await this.videoCallService.startScreenShare();
        this.isScreenSharing = true;
        this.setSuccess('Screen sharing started');
      }
    } catch (error) {
      this.setError('Failed to toggle screen sharing');
    }
  }

  endCall() {
    this.videoCallService.endCall();
    this.chatService.leaveRoom(this.roomId);
    this.leaveRoom.emit();
  }

  // Chat functions
  toggleChat() {
    this.showChat = !this.showChat;
    if (this.showChat) {
      this.unreadMessages = 0;
      setTimeout(() => this.scrollToBottom(), 100);
    }
  }

  sendMessage() {
    if (!this.newMessage.trim()) return;
    
    this.chatService.sendMessage(this.roomId, this.newMessage.trim(), this.currentUser);
    this.newMessage = '';
  }

  private scrollToBottom() {
    if (this.chatMessages) {
      const element = this.chatMessages.nativeElement;
      element.scrollTop = element.scrollHeight;
    }
  }

  // UI helpers
  copyRoomId() {
    navigator.clipboard.writeText(this.roomId).then(() => {
      this.setSuccess('Room ID copied to clipboard');
    }).catch(() => {
      this.setError('Failed to copy room ID');
    });
  }

  getStatusClass(): string {
    if (this.connectionStatus.includes('Connected')) return 'connected';
    if (this.connectionStatus.includes('Connecting')) return 'connecting';
    return 'failed';
  }

  getInitials(name: string): string {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'U';
  }

  formatTime(timestamp: any): string {
    if (!timestamp) return '';
    
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  // Dragging functionality for local video
  startDragging(event: PointerEvent) {
    this.isDragging = true;
    const rect = (event.target as HTMLElement).getBoundingClientRect();
    this.dragOffset.x = event.clientX - rect.left;
    this.dragOffset.y = event.clientY - rect.top;
    
    document.addEventListener('pointermove', this.onDrag.bind(this));
    document.addEventListener('pointerup', this.stopDragging.bind(this));
  }

  private onDrag(event: PointerEvent) {
    if (!this.isDragging) return;
    
    const container = document.querySelector('.video-area') as HTMLElement;
    const maxX = container.clientWidth - 220; // 200px width + 20px margin
    const maxY = container.clientHeight - 170; // 150px height + 20px margin
    
    this.localVideoPosition.x = Math.max(20, Math.min(maxX, event.clientX - this.dragOffset.x));
    this.localVideoPosition.y = Math.max(20, Math.min(maxY, event.clientY - this.dragOffset.y));
  }

  private stopDragging() {
    this.isDragging = false;
    document.removeEventListener('pointermove', this.onDrag.bind(this));
    document.removeEventListener('pointerup', this.stopDragging.bind(this));
  }

  // Error handling
  private setError(message: string) {
    this.errorMessage = message;
    this.successMessage = '';
    setTimeout(() => this.clearError(), 5000);
  }

  private setSuccess(message: string) {
    this.successMessage = message;
    this.errorMessage = '';
    setTimeout(() => this.clearSuccess(), 3000);
  }

  clearError() {
    this.errorMessage = '';
  }

  clearSuccess() {
    this.successMessage = '';
  }
}