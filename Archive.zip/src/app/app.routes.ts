// src/app/app.routes.ts
import { Routes } from '@angular/router';

export const routes: Routes = [
  // Default route - redirect to main app
  { 
    path: '', 
    redirectTo: '/app', 
    pathMatch: 'full' 
  },
  
  // Main app route (handled by AppComponent)
  { 
    path: 'app', 
    loadComponent: () => import('./app.component').then(m => m.AppComponent)
  },
  
  // Direct routes for components (optional - if you want separate pages)
  {
    path: 'auth',
    loadComponent: () => import('./components/auth/auth.component').then(m => m.AuthComponent)
  },
  
  {
    path: 'lobby',
    loadComponent: () => import('./components/lobby/lobby.component').then(m => m.LobbyComponent)
  },
  
  {
    path: 'call/:roomId',
    loadComponent: () => import('./components/video-call/video-call.component').then(m => m.VideoCallComponent)
  },
  
  // Wildcard route - redirect to main app
  { 
    path: '**', 
    redirectTo: '/app' 
  }
];

// Alternative simpler routes (if you want everything handled by AppComponent)
export const simpleRoutes: Routes = [
  { 
    path: '', 
    loadComponent: () => import('./app.component').then(m => m.AppComponent)
  },
  { 
    path: '**', 
    redirectTo: '' 
  }
];