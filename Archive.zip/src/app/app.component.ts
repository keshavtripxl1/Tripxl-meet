// app.component.ts - Updated with proper user validation
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { AuthService, User } from './services/auth.service';
import { AuthComponent } from './components/auth/auth.component';
import { VideoCallComponent } from './components/video-call/video-call.component';
import { LobbyComponent } from './components/lobby/lobby.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, AuthComponent, VideoCallComponent, LobbyComponent],
  templateUrl: `app.component.html`,
  styleUrls: [`app.component.css`]
})
export class AppComponent implements OnInit {
  isLoading = true;
  isAuthenticated = false;
  currentUser: User | null = null;
  currentView: 'lobby' | 'call' = 'lobby';
  currentRoomId: string | null = null;

  constructor(private authService: AuthService) {}

  async ngOnInit() {
    console.log('🚀 App initializing...');
    
    try {
      // Check if user is already authenticated
      const user = await this.authService.getCurrentUser();
      if (user) {
        console.log('✅ User found:', user);
        this.currentUser = user;
        this.isAuthenticated = true;
        
        // Set user as online
        await this.authService.setUserOnlineStatus(true);
      } else {
        console.log('❌ No authenticated user found');
      }
    } catch (error) {
      console.error('❌ Error checking auth state:', error);
    } finally {
      this.isLoading = false;
      console.log('✅ App initialization complete');
    }

    // Listen for auth state changes
    this.authService.authState$.subscribe(user => {
      console.log('🔄 Auth state changed:', user);
      this.currentUser = user;
      this.isAuthenticated = !!user;
      
      // If user logs out, return to lobby
      if (!user) {
        this.currentView = 'lobby';
        this.currentRoomId = null;
      }
    });
  }

  onAuthSuccess() {
    console.log('✅ Authentication successful');
    const user = this.authService.currentUser;
    
    if (user) {
      this.isAuthenticated = true;
      this.currentUser = user;
      console.log('✅ Current user set:', user);
    } else {
      console.error('❌ Auth success but no current user');
    }
  }

  onJoinRoom(roomId: string) {
    if (!this.currentUser) {
      console.error('❌ Cannot join room: No current user');
      return;
    }
    
    console.log('🚪 Joining room:', roomId);
    this.currentRoomId = roomId;
    this.currentView = 'call';
  }

  onCreateRoom() {
    if (!this.currentUser) {
      console.error('❌ Cannot create room: No current user');
      return;
    }
    
    const roomId = this.generateRoomId();
    console.log('🏠 Creating room:', roomId);
    this.currentRoomId = roomId;
    this.currentView = 'call';
  }

  onLeaveRoom() {
    console.log('👋 Leaving room');
    this.currentRoomId = null;
    this.currentView = 'lobby';
  }

  private generateRoomId(): string {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  }
}