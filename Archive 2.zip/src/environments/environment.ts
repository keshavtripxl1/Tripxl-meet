
// environments/environment.ts
export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDpmBtA9M6EnQ3K8A4poxA2XhCHlp9LtI4",
    authDomain: "chatapp-ed4ab.firebaseapp.com",
    projectId: "chatapp-ed4ab",
    storageBucket: "chatapp-ed4ab.firebasestorage.app",
    messagingSenderId: "68051279184",
    appId: "1:68051279184:web:1d09142162d95ff129a055",
    }
};


// export const firebaseConfig = {
//   apiKey: "AIzaSyDpmBtA9M6EnQ3K8A4poxA2XhCHlp9LtI4",
//   authDomain: "chatapp-ed4ab.firebaseapp.com",
//   projectId: "chatapp-ed4ab",
//   storageBucket: "chatapp-ed4ab.firebasestorage.app",
//   messagingSenderId: "68051279184",
//   appId: "1:68051279184:web:1d09142162d95ff129a055",
//   measurementId: "G-N4MGLJ1HWK"
// };

