import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService, User } from '../../services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-lobby',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: `lobby.component.html`,
  styleUrls: [`lobby.component.css`]
})
export class LobbyComponent implements OnInit, OnDestroy {
  @Input() currentUser: User | null = null;
  @Output() joinRoom = new EventEmitter<string>();
  @Output() createRoom = new EventEmitter<void>();

  meetingId = '';
  onlineUsers: User[] = [];
  errorMessage = '';
  successMessage = '';

  private subscriptions: Subscription[] = [];

  constructor(private authService: AuthService) {}

  ngOnInit() {
    this.loadOnlineUsers();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  private loadOnlineUsers() {
    const onlineUsersSub = this.authService.getOnlineUsers().subscribe({
      next: (users) => {
        this.onlineUsers = users;
      },
      error: (error) => {
        console.error('Error loading online users:', error);
        this.setError('Failed to load online users');
      }
    });

    this.subscriptions.push(onlineUsersSub);
  }

  createMeeting() {
    this.setSuccess('Creating new meeting...');
    setTimeout(() => {
      this.createRoom.emit();
    }, 500);
  }

  joinMeeting() {
    if (!this.meetingId.trim()) {
      this.setError('Please enter a meeting ID');
      return;
    }

    if (this.meetingId.length < 6) {
      this.setError('Meeting ID must be at least 6 characters');
      return;
    }

    this.setSuccess('Joining meeting...');
    setTimeout(() => {
      this.joinRoom.emit(this.meetingId.trim());
    }, 500);
  }

  inviteUser(user: User) {
    // Generate a meeting room and invite the user
    this.setSuccess(`Inviting ${user.displayName || 'User'} to a meeting...`);
    // In a real app, you would send a notification to the user
    setTimeout(() => {
      this.createRoom.emit();
    }, 1000);
  }

  async signOut() {
    try {
      await this.authService.signOut();
    } catch (error) {
      console.error('Error signing out:', error);
      this.setError('Failed to sign out');
    }
  }

  getUserInitials(): string {
    if (this.currentUser?.displayName) {
      return this.getInitials(this.currentUser.displayName);
    }
    return this.getInitials(this.currentUser?.phoneNumber || 'U');
  }

  getInitials(name: string): string {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'U';
  }

  formatPhoneNumber(phoneNumber: string): string {
    // Simple phone number formatting
    if (phoneNumber.length > 10) {
      return phoneNumber.replace(/(\+\d{1,3})(\d{3})(\d{3})(\d{4})/, '$1 $2-$3-$4');
    }
    return phoneNumber;
  }

  private setError(message: string) {
    this.errorMessage = message;
    this.successMessage = '';
    // Auto-clear after 5 seconds
    setTimeout(() => this.clearError(), 5000);
  }

  private setSuccess(message: string) {
    this.successMessage = message;
    this.errorMessage = '';
    // Auto-clear after 3 seconds
    setTimeout(() => this.clearSuccess(), 3000);
  }

  clearError() {
    this.errorMessage = '';
  }

  clearSuccess() {
    this.successMessage = '';
  }
}